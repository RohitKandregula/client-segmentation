# client-segmentation

Customer/Client Segmentation based on spending on various products
